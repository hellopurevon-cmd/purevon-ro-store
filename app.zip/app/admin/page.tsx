export default function AdminDashboard() {
    return (
      <div className="min-h-screen bg-zinc-950 text-white flex">
  
        {/* Sidebar */}
  
        <aside className="w-72 bg-black border-r border-zinc-800 p-6">
  
          <h1 className="text-3xl font-bold text-yellow-400">
            PUREVON
          </h1>
  
          <p className="text-zinc-500 mt-2">
            Premium Admin Panel
          </p>
  
          <nav className="mt-10 space-y-2">
  
            {[
              "Dashboard",
              "Products",
              "Categories",
              "Orders",
              "Customers",
              "Reviews",
              "Homepage",
              "Settings",
            ].map((item) => (
              <button
                key={item}
                className="w-full text-left px-4 py-3 rounded-lg hover:bg-zinc-900 transition"
              >
                {item}
              </button>
            ))}
  
          </nav>
  
        </aside>
  
        {/* Main */}
  
        <main className="flex-1 p-10">
  
          <h2 className="text-4xl font-bold">
            Dashboard
          </h2>
  
          <p className="text-zinc-400 mt-2">
            Welcome to Purevon Admin
          </p>
  
          {/* Stats */}
  
          <div className="grid grid-cols-4 gap-6 mt-10">
  
            <div className="bg-zinc-900 rounded-xl p-6">
              <p className="text-zinc-500">Products</p>
              <h3 className="text-4xl font-bold mt-3">0</h3>
            </div>
  
            <div className="bg-zinc-900 rounded-xl p-6">
              <p className="text-zinc-500">Orders</p>
              <h3 className="text-4xl font-bold mt-3">0</h3>
            </div>
  
            <div className="bg-zinc-900 rounded-xl p-6">
              <p className="text-zinc-500">Customers</p>
              <h3 className="text-4xl font-bold mt-3">0</h3>
            </div>
  
            <div className="bg-zinc-900 rounded-xl p-6">
              <p className="text-zinc-500">Revenue</p>
              <h3 className="text-4xl font-bold mt-3">₹0</h3>
            </div>
  
          </div>
  
        </main>
  
      </div>
    );
  }