import Link from "next/link";

export default function ProductsPage() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white p-10">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">Products</h1>
          <p className="text-zinc-400 mt-2">Manage all products</p>
        </div>

        <Link href="/admin/products/new">
          <button className="bg-yellow-400 text-black px-6 py-3 rounded-xl font-bold hover:bg-yellow-300">
            + Add Product
          </button>
        </Link>
      </div>

      <div className="bg-zinc-900 rounded-xl p-6">
        <h2 className="text-xl">Products page is working ✅</h2>
      </div>
    </div>
  );
}