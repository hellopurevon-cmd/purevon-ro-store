"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

type ProductForm = {
  name: string;
  brand: string;
  category: string;
  price: string;
  compare_price: string;
  stock: string;
  sku: string;
  short_description: string;
  description: string;
  featured: boolean;
  active: boolean;
};

function slugify(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function generateSku(name: string) {
  const base = slugify(name).toUpperCase().slice(0, 8) || "PV";
  const random = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${base}-${random}`;
}

export default function AddProductPage() {
  const supabase = createClient();
  const router = useRouter();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState<ProductForm>({
    name: "",
    brand: "Purevon",
    category: "Wellness",
    price: "",
    compare_price: "",
    stock: "0",
    sku: "",
    short_description: "",
    description: "",
    featured: false,
    active: true,
  });

  const updateField = <K extends keyof ProductForm>(
    key: K,
    value: ProductForm[K]
  ) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (loading) return;

    setLoading(true);
    setError(null);

    try {
      const trimmedName = formData.name.trim();
      if (!trimmedName) throw new Error("Product name is required.");

      const priceValue = Number(formData.price);
      if (!Number.isFinite(priceValue) || priceValue <= 0) {
        throw new Error("Selling price is required.");
      }

      const slug = slugify(trimmedName);
      const sku = formData.sku.trim() || generateSku(trimmedName);

      const payload = {
        name: trimmedName,
        slug,
        description: formData.description.trim() || null,
        short_description: formData.short_description.trim() || null,
        price: priceValue,
        compare_price:
          formData.compare_price.trim() !== ""
            ? Number(formData.compare_price)
            : null,
        category: formData.category.trim() || null,
        brand: formData.brand.trim() || null,
        stock:
          formData.stock.trim() !== "" ? Number(formData.stock) : 0,
        sku,
        featured: formData.featured,
        active: formData.active,
        image_url: null,
      };

      const { data, error: insertError } = await supabase
        .from("products")
        .insert(payload)
        .select()
        .single();

      if (insertError) {
        throw insertError;
      }

      if (!data) {
        throw new Error("Product saved but no response returned.");
      }

      router.push("/admin/products");
      router.refresh();
    } catch (err) {
      console.error("Save product error:", err);
      const message =
        err instanceof Error ? err.message : "Something went wrong.";
      setError(message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-white p-6 md:p-10">
      <div className="mx-auto max-w-5xl">
        <div className="mb-8">
          <p className="text-sm uppercase tracking-[0.3em] text-zinc-500">
            Purevon Admin
          </p>
          <h1 className="mt-3 text-4xl font-bold text-yellow-400 md:text-5xl">
            Add New Product
          </h1>
          <p className="mt-3 max-w-2xl text-zinc-400">
            Create a premium product entry for the Purevon catalog. This
            interface is designed for fast admin editing and future RO-compatible
            product workflows.
          </p>
        </div>

        {error ? (
          <div className="mb-6 rounded-2xl border border-red-500/30 bg-red-500/10 px-5 py-4 text-red-300">
            {error}
          </div>
        ) : null}

        <form
          onSubmit={handleSubmit}
          className="space-y-6 rounded-3xl border border-zinc-800 bg-zinc-900/95 p-6 md:p-8 shadow-2xl shadow-black/30"
        >
          <div>
            <label className="mb-2 block text-sm font-semibold text-zinc-200">
              Product Name
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => updateField("name", e.target.value)}
              placeholder="Enter product name"
              className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
            />
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-200">
                Brand
              </label>
              <input
                type="text"
                value={formData.brand}
                onChange={(e) => updateField("brand", e.target.value)}
                placeholder="Purevon"
                className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-200">
                Category
              </label>
              <input
                type="text"
                value={formData.category}
                onChange={(e) => updateField("category", e.target.value)}
                placeholder="Wellness"
                className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
              />
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-200">
                MRP
              </label>
              <input
                type="number"
                value={formData.compare_price}
                onChange={(e) => updateField("compare_price", e.target.value)}
                placeholder="999"
                className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-200">
                Selling Price
              </label>
              <input
                type="number"
                value={formData.price}
                onChange={(e) => updateField("price", e.target.value)}
                placeholder="799"
                className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold text-zinc-200">
                Stock
              </label>
              <input
                type="number"
                value={formData.stock}
                onChange={(e) => updateField("stock", e.target.value)}
                placeholder="0"
                className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
              />
            </div>
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-zinc-200">
              SKU (optional)
            </label>
            <input
              type="text"
              value={formData.sku}
              onChange={(e) => updateField("sku", e.target.value)}
              placeholder="Leave blank to auto-generate"
              className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-zinc-200">
              Short Description
            </label>
            <textarea
              rows={3}
              value={formData.short_description}
              onChange={(e) => updateField("short_description", e.target.value)}
              placeholder="Short summary for cards and listings"
              className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-zinc-200">
              Full Description
            </label>
            <textarea
              rows={7}
              value={formData.description}
              onChange={(e) => updateField("description", e.target.value)}
              placeholder="Detailed product description"
              className="w-full rounded-xl border border-zinc-700 bg-zinc-800 px-4 py-3 text-white outline-none transition focus:border-yellow-400"
            />
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
              <label className="mb-3 block text-sm font-semibold text-zinc-200">
                Featured Product
              </label>
              <label className="flex cursor-pointer items-center gap-3 text-zinc-300">
                <input
                  type="checkbox"
                  checked={formData.featured}
                  onChange={(e) => updateField("featured", e.target.checked)}
                  className="h-4 w-4 accent-yellow-400"
                />
                Highlight this product on homepage and collection pages
              </label>
            </div>

            <div className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-5">
              <label className="mb-3 block text-sm font-semibold text-zinc-200">
                Active
              </label>
              <label className="flex cursor-pointer items-center gap-3 text-zinc-300">
                <input
                  type="checkbox"
                  checked={formData.active}
                  onChange={(e) => updateField("active", e.target.checked)}
                  className="h-4 w-4 accent-yellow-400"
                />
                Product is visible in the live store
              </label>
            </div>
          </div>

          <div className="rounded-2xl border border-dashed border-yellow-400/40 bg-yellow-400/5 p-5">
            <h2 className="text-lg font-semibold text-yellow-400">
              RO Compatibility Plan
            </h2>
            <p className="mt-2 text-sm leading-6 text-zinc-300">
              In the next step, we will add a compatibility selector and a
              checkout confirmation checkbox so the customer confirms this
              product is suitable for their RO system before ordering.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-zinc-500">
              Slug and SKU are generated automatically if left blank.
            </p>

            <button
              type="submit"
              disabled={loading}
              className="inline-flex items-center justify-center rounded-xl bg-yellow-400 px-8 py-4 font-bold text-black transition hover:bg-yellow-300 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {loading ? "Saving..." : "Save Product"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}