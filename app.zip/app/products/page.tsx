import Link from "next/link";
export default function ProductsPage() {
    return (
      <div className="min-h-screen bg-zinc-950 text-white p-10">
  
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold">
              Products
            </h1>
  
            <p className="text-zinc-400 mt-2">
              Manage all products
            </p>
          </div>
  
          <Link
  href="/admin/products/new"
  className="bg-yellow-400 text-black px-6 py-3 rounded-xl font-bold hover:bg-yellow-300"
>
  + Add Product
</Link>
        </div>
  
        <div className="bg-zinc-900 rounded-xl overflow-hidden">
  
          <table className="w-full">
  
            <thead className="bg-zinc-800">
  
              <tr>
  
                <th className="text-left p-4">Image</th>
                <th className="text-left p-4">Product</th>
                <th className="text-left p-4">Category</th>
                <th className="text-left p-4">Price</th>
                <th className="text-left p-4">Stock</th>
                <th className="text-left p-4">Status</th>
                <th className="text-left p-4">Action</th>
  
              </tr>
  
            </thead>
  
            <tbody>
  
              <tr className="border-t border-zinc-800">
  
                <td className="p-4">📦</td>
  
                <td className="p-4">
                  Premium Product
                </td>
  
                <td className="p-4">
                  Wellness
                </td>
  
                <td className="p-4">
                  ₹999
                </td>
  
                <td className="p-4">
                  25
                </td>
  
                <td className="p-4 text-green-400">
                  Active
                </td>
  
                <td className="p-4 space-x-2">
  
                  <button className="bg-blue-600 px-3 py-2 rounded">
                    Edit
                  </button>
  
                  <button className="bg-red-600 px-3 py-2 rounded">
                    Delete
                  </button>
  
                </td>
  
              </tr>
  
            </tbody>
  
          </table>
  
        </div>
  
      </div>
    );
  }